if [ -f "${0%/*}/tools/bin/tools" ]; then
	MODDIR="${0%/*}"
	operate="backup"
	. "${0%/*}/tools/bin/tools"
else
	echo "${0%/*}/tools/bin/tools遗失"
fi